Vous venez de télécharger un modèle et une fiche pédagogique produits dans le cadre du réseau MAPS.
Retrouvez toute l'actualité du réseau sur http://maps.hypotheses.org/
Retrouvez toutes les productions sur gitHub 

***Comment installer***
Le modèle fonctionne sur le logiciel NetLogo, en version 5.0 ou au-dessus.
Pour installer NetLogo, allez sur site http://ccl.northwestern.edu/netlogo/
et téléchargez le logiciel gratuitement.
Pour lancer le modèle, double cliquez sur le fichier du modèle (fichier
nlogo).

***How To Install***
The model runs under NetLogo version 5.0 or above.
To install NetLogo, visit NetLogo website at
http://ccl.northwestern.edu/netlogo/.
To launch the model double clic on the model file (nlogo file).
