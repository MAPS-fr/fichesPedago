

import org.openmole.plugin.domain.collection._
import org.openmole.plugin.domain.distribution._
import org.openmole.plugin.domain.modifier._
import org.openmole.plugin.sampling.combine._
import org.openmole.plugin.task.groovy._
import org.openmole.plugin.task.netlogo5._
import org.openmole.plugin.hook.display._
import org.openmole.plugin.hook.file._

// Declare the variable

val seed = Prototype[Int]("seed")

val galpha = Prototype[Double]("galpha")
val galphaAirplane = Prototype[Double]("galpha-airplane")
val gbeta = Prototype[Double]("gbeta")
val gbetaAirplane = Prototype[Double]("gbeta-airplane")
val ggamma = Prototype[Double]("ggamma")
val gbirth = Prototype[Double]("gbirth")
val gdead2 = Prototype[Double]("gdead2")
val gdead1 = Prototype[Double]("gdead1")
  
val gnumberNodes = Prototype[Int]("gnumber-nodes")
val gradiusRandomNetwork = Prototype[Double]("gradius-random-network")
val grewiringProbabilitySmallWorld = Prototype[Double]("grewiring-probability-SmallWorld")
val gnetworkChoice = Prototype[String]("gnetwork-choice") 
  
val gtypeOfAgents = Prototype[String]("typeOfAgents")
val gstrategy1 = Prototype[Boolean]("gstrategy1")
val gstrategy2 = Prototype[Boolean] ("gstrategy2")
val gstrategy3 = Prototype[Boolean] ("gstrategy3")
val gstrategy4 = Prototype[Boolean] ("gstrategy4")
val greducContagion = Prototype[Double] ("greduc-contagion")
val gstrategy4Global = Prototype[Boolean]("gstrategy4-global")
val gpcr = Prototype[Double] ("gpcr")
val gtheta1 = Prototype[Double] ("gtheta1")
val gtheta2 = Prototype[Double] ("gtheta2")  
val gmobilityRate = Prototype[Double] ("gmobility-rate")

val gTerritorySizeKm = Prototype[Int] ("gTerritorySize-km")
val gDurationEpidemyDays = Prototype[Int] ("gDurationEpidemy-days")
val gEpsilon = Prototype[Double] ("gEpsilon")
val gPopulationAtCalibrageNode  = Prototype[Double] ("gPopulation-at-Calibrage-Node") 
 
val gh = Prototype[Double] ("gh")
val gSusceptibleAtNode = Prototype[Double] ("gSusceptible-At-node")
val gInfectedAtNode = Prototype[Double] ("gInfected-At-node")
val gRecoveredAtNode = Prototype[Double] ("gRecovered-At-Node")

val gMinGroupSize = Prototype[Int]("gMinGroupSize")
val gMaxGroupSize = Prototype[Int]("gMaxGroupSize")
val gFlightThreshold = Prototype[Double]("gFlgiht-Threshold")

val gdurationOfEpidemy = Prototype[Double]("gduration-of-Epidemy")
val gpercolationTime = Prototype[Double]("gpercolation-time")
val goutTrafficReduction = Prototype[Double]("gout-traffic-reduction")
val gtotalNumberPeopleInfected = Prototype[Double]("gtotal-number-people-infected")

// Define the Hello task
val cmds = List("random-seed ${seed}", "setup-openmole", "main-loop-openmole")
//val micmac = NetLogo5Task("MicMacTask", "/media/38109D261F16B878/TRAVAUX/My Dropbox/MAPS4-DreamTeam/codes/SRC/v25_rungekutta_OMole/MICMAC-V25.nlogo", cmds, true)
val micmac = NetLogo5Task("MicMacTask", "/iscpif/users/rey/MAPS4/v28_rungekutta_OMole/MICMAC-V28.nlogo", cmds, true)

micmac addInput(seed)

micmac addParameter(gbeta,0.001)
micmac addParameter(galphaAirplane,0.100)
micmac addParameter(galpha,0.100)
micmac addParameter(gbetaAirplane,0.001)
micmac addParameter(ggamma,0.0)
micmac addParameter(gbirth,0.0)
micmac addParameter(gdead2,0.0)
micmac addParameter(gdead1,0.0)
  
micmac addParameter(gnumberNodes,10)
micmac addParameter(gradiusRandomNetwork,14.0)
micmac addParameter(grewiringProbabilitySmallWorld,1.0)
micmac addParameter(gnetworkChoice,"complete")
  
micmac addParameter(gtypeOfAgents,"sir")
micmac addParameter(gstrategy1,true)
micmac addParameter(gstrategy2,true)
micmac addParameter(gstrategy3,true)
micmac addParameter(gstrategy4,true)
micmac addParameter(greducContagion,0.9)
micmac addParameter(gstrategy4Global,false)
micmac addParameter(gpcr,0.5)
micmac addParameter(gtheta1,0.0100)
micmac addParameter(gtheta2,0.0100)
micmac addParameter(gmobilityRate,0.10)

micmac addParameter(gTerritorySizeKm,1000)
micmac addParameter(gDurationEpidemyDays,10)
micmac addParameter(gEpsilon,0.01)
micmac addParameter(gPopulationAtCalibrageNode,10000.0)
 
micmac addParameter(gh,0.01)
micmac addParameter(gSusceptibleAtNode,10000.0)
micmac addParameter(gInfectedAtNode,0.0)
micmac addParameter(gRecoveredAtNode,0.0)

micmac addParameter(gMinGroupSize,10)
micmac addParameter(gMaxGroupSize,200)
micmac addParameter(gFlightThreshold,1.0)

micmac addNetLogoInput (galpha,"galpha")
micmac addNetLogoInput (galphaAirplane,"galpha-airplane")
micmac addNetLogoInput (gbeta,"gbeta")
micmac addNetLogoInput (gbetaAirplane,"gbeta-airplane")

micmac addNetLogoInput (ggamma,"ggamma")
micmac addNetLogoInput (gbirth,"gbirth")
micmac addNetLogoInput (gdead1,"gdead1" )
micmac addNetLogoInput (gdead2,"gdead2")

micmac addNetLogoInput (gnumberNodes,"gnumber-nodes" )
micmac addNetLogoInput (gradiusRandomNetwork,"gradius-random-network")

micmac addNetLogoInput (grewiringProbabilitySmallWorld,"grewiring-probability-SmallWorld")
micmac addNetLogoInput (gnetworkChoice,"gnetwork-choice")

micmac addNetLogoInput (gtypeOfAgents,"typeOfAgents")
micmac addNetLogoInput (gstrategy1,"gstrategy1")
micmac addNetLogoInput (gstrategy2,"gstrategy2")
micmac addNetLogoInput (gstrategy3,"gstrategy3")
micmac addNetLogoInput (gstrategy4,"gstrategy4")

micmac addNetLogoInput (greducContagion,"greduc-contagion")
micmac addNetLogoInput (gstrategy4Global,"gstrategy4-global")

micmac addNetLogoInput (gpcr,"gpcr")
micmac addNetLogoInput (gtheta1,"gtheta1")
micmac addNetLogoInput (gtheta2,"gtheta2")
micmac addNetLogoInput (gmobilityRate,"gmobility-rate")

micmac addNetLogoInput (gTerritorySizeKm,"gTerritorySize-km")
micmac addNetLogoInput (gDurationEpidemyDays,"gDurationEpidemy-days")
micmac addNetLogoInput (gEpsilon,"gEpsilon")
micmac addNetLogoInput (gPopulationAtCalibrageNode,"gPopulation-at-Calibrage-Node")

micmac addNetLogoInput (gh,"gh")
micmac addNetLogoInput (gSusceptibleAtNode,"gSusceptible-At-node")
micmac addNetLogoInput (gInfectedAtNode,"gInfected-At-node")
micmac addNetLogoInput (gRecoveredAtNode,"gRecovered-At-Node")

micmac addNetLogoInput (gMinGroupSize,"gMinGroupSize")
micmac addNetLogoInput (gMaxGroupSize,"gMaxGroupSize")
micmac addNetLogoInput (gFlightThreshold,"gFlight-Threshold")

micmac addNetLogoOutput ("gduration-of-Epidemy",gdurationOfEpidemy)
micmac addNetLogoOutput ("gpercolation-time",gpercolationTime)
micmac addNetLogoOutput ("gtotal-number-people-infected",gtotalNumberPeopleInfected)
micmac addNetLogoOutput ("gout-traffic-reduction",goutTrafficReduction)

//////////////////////////
import org.openmole.plugin.builder.stochastic._

val medNumberPeopleInfected = Prototype[Double]("medNumberPeopleInfected")
val medOutTrafficReduction = Prototype[Double]("medOutTrafficReduction")

val modelCapsule = Capsule(micmac)

val stat = new Statistics()
stat.addMedian(gtotalNumberPeopleInfected, medNumberPeopleInfected)
stat.addMedian(goutTrafficReduction, medOutTrafficReduction)

val seedFactor = Factor(seed, UniformIntDistribution() take 10)
val replicateModel = statistics("replicateModel", modelCapsule, seedFactor, stat)

//val ex = (replicateModel hook ToStringHook()) toExecution

import org.openmole.plugin.builder.evolution._
import org.openmole.plugin.method.evolution._

// Define the population (100) and the number of generation (100)
val evolution =
  GA (
    algorithm = GA.optimization(100),
    lambda = 1,
    termination = GA.timed(60 * 60 * 1000)
  )


val nsga2  =
  steadyGA(evolution)(
    "calibrateModel",
    replicateModel,
    List( gpcr -> ("0.0","1.0"), gtheta1 -> ("0.0","1.0"), gtheta2 -> ("0.0","1.0"), greducContagion -> ("0.0","1.0")),
    List(medNumberPeopleInfected -> "0", medOutTrafficReduction -> "0")
  )

import org.openmole.plugin.environment.glite._

val env = GliteEnvironment("vo.complex-systems.eu", openMOLEMemory = 1400, wallTime = "PT4H")
//val env = LocalEnvironment(10)
//GliteAuthentication() = P12Certificate(encrypted, "/iscpif/users/rey/CERTIF/certif.p12")

// 5000 = nb ilot , 100000 = cond arret , 50 = echantillonage 
val islandModel = islandGA(nsga2)("island", 1000, GA.counter(100000), 50)

val display = DisplayHook("Generation ${" + islandModel.generation.name + "}, convergence ${" + islandModel.state.name + "}")

/*val saveParetoHook = AppendToCSVFileHook("/tmp/pareto${" + islandModel.generation.name + "}.csv", gtheta1.toArray, gtheta2.toArray, gpcr.toArray, greducContagion.toArray, medOutTrafficReduction.toArray, medNumberPeopleInfected.toArray)
*/

val saveParetoHook = AppendToCSVFileHook("/iscpif/users/rey/RESULT_MAPS4_v28/pareto${" + islandModel.generation.name + "}.csv", gtheta1.toArray, gtheta2.toArray, gpcr.toArray, greducContagion.toArray, medOutTrafficReduction.toArray, medNumberPeopleInfected.toArray)

val ex = MoleExecution(
      islandModel,
      environments = Map(islandModel.island -> env),
      hooks = List(islandModel.outputCapsule -> saveParetoHook, islandModel.outputCapsule -> display)
    )

ex.start

/*
val ex = exploration -< (nsga2 hook ToStringHook()) toExecution (hooks = List(nsga2.outputCapsule -> saveParetoHook))
*/

